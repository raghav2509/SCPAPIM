var requesta=context.getVariable("request1");


var request2= requesta.replace('<?xml version="1.0" encoding="UTF-8"?>','<n0:AccountListQuery_Request xmlns:n0="http://amwater.com/RTC/000922/PI/BusinessTechnicalMasterData">');
var request3 =request2.concat("</n0:AccountListQuery_Request>");
var str='<?xml version="1.0" encoding="UTF-8"?>';
request4=str.concat(request3);
context.setVariable("request.content",request4);